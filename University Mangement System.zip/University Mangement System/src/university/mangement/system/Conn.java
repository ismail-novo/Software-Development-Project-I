package university.mangement.system;
import java.sql.*;
public class Conn {
    Connection c;
    Statement s;
    Conn(){
        try{
            Class.forName("com.mysql.cj.jdbc.Driver");
            c = DriverManager.getConnection("jdbc:mysql:///ismailzahid", "root", "IsmaIlZ@h1610");
            s = c.createStatement();
        }catch(Exception e){
            e.printStackTrace();
        }
    }
}
